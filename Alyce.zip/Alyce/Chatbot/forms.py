from django import forms
from .models import Conversation

class ConversationForm(forms.ModelForm):
    class Meta:
        model = Conversation
        fields = ['user', 'message']


        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            # Customize the form field attributes if needed
            self.fields['user'].widget.attrs['readonly'] = True  # Make the 'user' field readonly