from django.shortcuts import get_object_or_404, render, redirect
from .forms import ConversationForm
from .models import Conversation
from django.http import JsonResponse
import random

def home(request):
    # Add any necessary logic here
    return render(request, 'home.html')

def create_conversation(request):
    if request.method == 'POST':
        form = ConversationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('conversation_list')  # Redirect to conversation list page after successful creation
    else:
        form = ConversationForm()
    
    return render(request, 'create_conversation.html', {'form': form})

def conversation_list(request):
    conversations = Conversation.objects.all()  # Retrieve all conversations from the database
    return render(request, 'conversation_list.html', {'conversations': conversations})


def update_conversation(request, conversation_id):
    conversation = get_object_or_404(Conversation, pk=conversation_id)
    if request.method == 'POST':
        form = ConversationForm(request.POST, instance=conversation)
        if form.is_valid():
            # Update the conversation attributes
            conversation.user = form.cleaned_data['user']
            conversation.message = form.cleaned_data['message']
            conversation.save()
            return redirect('conversation_list')  # Redirect to conversation list page after successful update
    else:
        form = ConversationForm(instance=conversation)
    
    return render(request, 'update_conversation.html', {'form': form})


def delete_conversation(request, conversation_id):
    conversation = get_object_or_404(Conversation, pk=conversation_id)
    conversation.delete()
    return redirect('conversation_list')  # Redirect to conversation list page after successful deletion

def generate_chatbot_response(user_input):
    # Implement your logic to generate a chatbot response based on the user input
    
    # Example: Generate a random response from a list of predefined responses
    responses = [
        "Hello! How can I assist you today?",
        "I'm sorry, I didn't understand. Could you please rephrase your question?",
        "That's a great question! Let me find the answer for you.",
        "I'm here to help. What do you need assistance with?",
    ]
    
    return random.choice(responses)

def chatbot(request):
    if request.method == 'POST':
        # Logic to process user input and generate a response
        user_input = request.POST.get('message')
        # Perform natural language processing and generate a response
        response = generate_chatbot_response(user_input)
        # Return the response as JSON
        return JsonResponse({'response': response})

    return render(request, 'chatbot.html')
